from django.shortcuts import render,redirect,get_object_or_404
from .models import Account
from django.forms import ModelForm

class AccountForm(ModelForm):
    class Meta:
        model = Account
        fields = ['C_name','Bank_balance','Salary','Rent','Groceries','Heath_and_insurance','Clothing','Transport','shares_profit']
def account_list(request):
    context = {}

    # add the dictionary during initialization
    context["object_list"] = Account.objects.all()

    return render(request, "account_list.html", context)
def account_view(request, pk, template_name='account_details.html'):
    account = get_object_or_404(Account, pk=pk)
    return render(request, template_name, {'object': account})

def account_create(request, template_name='account_form.html'):
    form = AccountForm(request.POST or None)
    if form.is_valid():
        form.save()
        return redirect('account_list')
    return render(request, template_name, {'form': form})
def account_update(request, pk, template_name='account_form.html'):
    account = get_object_or_404(Account, pk=pk)
    form = AccountForm(request.POST or None, instance=account)
    if form.is_valid():
        form.save()
        return redirect('account_list')
    return render(request, template_name, {'form': form})

def account_delete(request, pk, template_name='account_confirm_delete.html'):
    account= get_object_or_404(Account, pk=pk)
    if request.method=='POST':
        account.delete()
        return redirect('account_list')
    return render(request, template_name, {'object': account})