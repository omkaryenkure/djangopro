from django.contrib import admin
from django.urls import path
from account import views
from django.http import HttpResponse
urlpatterns = [
    path('', views.account_list,name='account_list'),
    path('view/<int:pk>/', views.account_view, name='account_view'),
    path('new', views.account_create, name='account_new'),
  #  path('view/<int:pk>', views.AccountView.as_view(), name='account_view'),
    path('edit/<int:pk>', views.account_update, name='account_edit'),
    path('delete/<int:pk>', views.account_delete, name='account_delete'),


]