from django.urls import path

from . import views

urlpatterns = [
    path('', views.AccountList.as_view(), name='account_list'),
    path('view/<int:pk>', views.AccountView.as_view(), name='account_view'),
    path('new', views.AccountCreate.as_view(), name='account_new'),
  #  path('view/<int:pk>', views.AccountView.as_view(), name='account_view'),
    path('edit/<int:pk>', views.AccountUpdate.as_view(), name='account_edit'),
    path('delete/<int:pk>', views.AccountDelete.as_view(), name='account_delete'),
]