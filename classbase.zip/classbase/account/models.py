from django.db import models
# Create your models here.

class Profile(models.Model):
    C_name=models.CharField(max_length=30)
    bank_name=models.CharField(max_length=30)
    IFSC_code=models.CharField(max_length=30)
    Address=models.CharField(max_length=30)
    city=models.CharField(max_length=30)

    def __str__(self):
        return self.C_name



class Account(models.Model):
    Bank_balance = models.IntegerField()
    Salary=models.IntegerField()
    Rent=models.IntegerField()
    Groceries=models.IntegerField()
    Heath_and_insurance=models.IntegerField()
    Clothing=models.IntegerField()
    Transport=models.IntegerField()
    shares_profit= models.IntegerField()
    saving=models.IntegerField(blank=True, null=True, editable=False)
    New_bank_balance = models.IntegerField(blank=True, null=True, editable=False)
    C_name=models.ForeignKey(Profile, on_delete=models.CASCADE)
#    result = Profile.objects.all().annotate(prod=F('Salary') * F('Rent'))

    def get_absolute_url(self):
        return reverse('account_edit', kwargs={'pk': self.pk})

    def save(self,*args, **kwargs):
    #    self.result = Acc.objects.all().annotate(prod=F('number_1') * F('number_2'))
        self.saving = int(self.Salary+self.shares_profit-self.Rent-self.Groceries-self.Clothing-self.Heath_and_insurance-self.Transport)
        #print(Profile.Bank_balance)
        self.New_bank_balance = (self.Bank_balance)+(self.saving)
        super().save(*args, **kwargs)
