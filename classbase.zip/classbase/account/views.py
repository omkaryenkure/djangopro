from django.shortcuts import render
from django.http import HttpResponse
from django.views.generic import ListView, DetailView
from django.views.generic.edit import CreateView, UpdateView, DeleteView
from django.urls import reverse_lazy

from account.models import Account
class AccountList(ListView):
    model = Account

class AccountView(DetailView):
    model = Account

class AccountCreate(CreateView):
    model = Account
    fields = ['C_name', 'Bank_balance', 'Salary', 'Rent', 'Groceries', 'Heath_and_insurance', 'Clothing', 'Transport',
              'shares_profit']
    success_url = reverse_lazy('account_list')

class AccountUpdate(UpdateView):
    model = Account
    fields = ['C_name', 'Bank_balance', 'Salary', 'Rent', 'Groceries', 'Heath_and_insurance', 'Clothing', 'Transport',
              'shares_profit']
    success_url = reverse_lazy('account_list')

class AccountDelete(DeleteView):
    model = Account
    success_url = reverse_lazy('account_list')
# Create your views here.
